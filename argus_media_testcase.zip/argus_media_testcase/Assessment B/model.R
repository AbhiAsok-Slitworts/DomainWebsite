# Model Selection: ARIMA
# Why ARIMA?
#   
# Flexibility: ARIMA models can handle a wide range of time series data, including non-stationary data.
# Components: ARIMA combines autoregressive (AR) and moving average (MA) components, which helps in capturing various patterns in the data.
# Differencing: The integrated (I) part of ARIMA allows for differencing the data to make it stationary, which is crucial for accurate modeling.


# Steps to Select ARIMA Model:

# Visual Inspection: Plot the time series data to understand its behavior over time.
# Stationarity Check: Use the Augmented Dickey-Fuller (ADF) test to check if the data is stationary. If not, apply differencing.
# ACF and PACF Plots: Analyze the Autocorrelation Function (ACF) and Partial Autocorrelation Function (PACF) plots to identify the potential order of AR and MA components.
# Model Fitting: Fit different ARIMA models with varying orders and compare their performance using criteria like AIC (Akaike Information Criterion) and BIC (Bayesian Information Criterion).

# Model Diagnostics
# 1. Residual Analysis:
#   
# Plot Residuals: Plot the residuals to check for any patterns. Ideally, residuals should resemble white noise, indicating that the model has captured all the information in the data.
# ACF of Residuals: Plot the ACF of residuals to ensure there are no significant autocorrelations left. This indicates that the residuals are uncorrelated and the model is adequate.
# Ljung-Box Test: Perform the Ljung-Box test on residuals to statistically confirm the absence of autocorrelation.

# 2. Model Accuracy:
# Forecast Accuracy: Use metrics like Mean Absolute Error (MAE), Mean Squared Error (MSE), and Root Mean Squared Error (RMSE) to evaluate the accuracy of the model's forecasts.
# Train-Test Split: Split the data into training and test sets. Fit the model on the training set and evaluate its performance on the test set to ensure it generalizes well to unseen data.


# Load packages
library(gamlss)
library(gamlss.add)
library(gamlss.dist)
library(ggplot2)
library(dplyr)
library(forecast)
library(lubridate)

# Function to load and prepare data
prepare_data <- function(data) {
  data$Date <- as.Date(c(0:999), origin="2016-06-01")
  data_new <- data[, c("OILPRICE", "Date")]
  return(data_new)
}

# Function to plot oil price over time
plot_oil_price <- function(data_new) {
  ggplot(data_new) +
    aes(x = Date, y = OILPRICE) + 
    geom_line(color = 'steelblue') + 
    labs(title = 'Oil Price', x = 'Time Period') + 
    theme_minimal() + 
    theme(
      plot.title = element_text(hjust = 0.45),
      panel.grid.minor.x = element_blank(),
      axis.ticks.x = element_line(color = "grey")
    )
}

# Function to plot seasonal analysis of oil price
plot_seasonal_analysis <- function(data_new) {
  data_new %>%
    mutate(year = as.factor(year(Date))) %>%
    mutate(new_date = as.Date(paste0('2016-', month(Date),'-', day(Date)))) %>% 
    ggplot() + 
    aes(x = new_date, y = data_new$OILPRICE, color = year) + 
    geom_line() +
    labs(title = "Seasonal Analysis of Oil Price", x = '', y = 'Oil Price') + 
    scale_x_date(date_labels = '%b')
}

# Function to split data into training and test sets
split_data <- function(data_new, train_ratio = 0.80) {
  n <- nrow(data_new)
  train_rows <- floor(n * train_ratio)
  train <- data_new[1:train_rows,]
  test <- data_new[(train_rows + 1):n,]
  return(list(train = train, test = test))
}

# Function to create and summarize ARIMA model using auto.arima
create_arima_model <- function(train_data) {
  data_train_ts <- ts(train_data$OILPRICE)
  fa <- auto.arima(data_train_ts)
  summary(fa)
  return(fa)
}

# Function to evaluate ARIMA model
evaluate_arima_model <- function(fa, test_data) {
  test_rows <- nrow(test_data)
  data_test_ts <- ts(test_data$OILPRICE)
  prediction_arima <- ts(fa %>% forecast(h = test_rows))
  accuracy <- forecast::accuracy(as.numeric((prediction_arima$mean)), as.numeric((data_test_ts)))
  return(accuracy)
}

# Function to plot ARIMA predictions
plot_arima_predictions <- function(fa, train_data, test_rows) {
  data_train_ts <- ts(train_data$OILPRICE)
  data_train_ts %>% 
    autoplot(series = "historical") + 
    autolayer(fa %>% forecast(h = test_rows))  + 
    labs(title = "ARIMA - Actuals vs Predictions", y = "Oil Price in log")
}

# Function to plot residuals of ARIMA model
plot_residuals <- function(fa) {
  fa %>% residuals() %>%
    ggtsdisplay()
}

# Function to perform Ljung-Box test on residuals
ljung_box_test <- function(fa) {
  Box.test(fa$residuals, lag = 20, type = "Ljung-Box")
}

# Function to fit ARIMA model to entire dataset and predict future values
predict_future_values <- function(data_new, h = 10) {
  data_new_ts <- ts(data_new$OILPRICE)
  final_fit <- auto.arima(data_new_ts)
  predictions <- ts(final_fit %>% forecast(h = h))
  df <- as.data.frame(predictions$mean)
  df$Date <- as.Date(c(1:h), origin = "2019-02-25")
  names(df) <- c('OILPRICE', "Date")
  df <- df %>% select("Date", everything())
  return(df)
}

# Main script
data <- oil
data_new <- prepare_data(data)

# Plotting
dev.new()
plot_oil_price(data_new)
plot_seasonal_analysis(data_new)

# Splitting data
split <- split_data(data_new)
train <- split$train
test <- split$test

# ARIMA model
fa <- create_arima_model(train)
accuracy <- evaluate_arima_model(fa, test)
print(accuracy)

# Plot ARIMA predictions
plot_arima_predictions(fa, train, nrow(test))

# Plot residuals
plot_residuals(fa)

# Perform Ljung-Box test on residuals
ljung_box_test(fa)

# Predict future values
future_predictions <- predict_future_values(data_new, h = 10)
print(future_predictions)







