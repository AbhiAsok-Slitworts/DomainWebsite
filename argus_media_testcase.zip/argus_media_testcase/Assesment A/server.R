library(shiny)
library(gamlss)
library(ggplot2)
library(plotly)
library(reshape2)
library(zoo)
library(dplyr)  # For lagging
library(tseries)  # For ADF test
library(DT)  # For displaying data tables

# Load the oil dataset
data("oil", package = "gamlss")

# Add Date column
oil$Date <- as.Date(c(0:999), origin = "2016-06-01")

# Function to calculate rolling standard deviation
rolling_sd <- function(x, window) {
  rollapply(x, width = window, FUN = sd, fill = NA, align = "right")
}

# Function to calculate rolling mean
rolling_mean <- function(x, window) {
  rollapply(x, width = window, FUN = mean, fill = NA, align = "right")
}

# Function to create lagged series
lag_series <- function(x, order) {
  dplyr::lag(x, n = order)
}

# Function to calculate difference
calculate_difference <- function(x, y) {
  x - y
}

# Function to perform normality test
normality_test <- function(x) {
  shapiro.test(x)
}

# Function to perform stationarity test
stationarity_test <- function(x) {
  adf.test(na.omit(x))  # Remove NA values before performing the test
}

# Function to calculate correlation coefficient
correlation_coefficient <- function(x, y) {
  cor(x, y, use = "complete.obs")
}

# Initialize metadata object
metadata <- list()

# Define server logic for the Shiny dashboard
server <- function(input, output, session) {
  output$scatterPlot <- renderPlotly({
    p <- ggplot(oil, aes(x = OILPRICE, y = SPX_log)) +
      geom_point(color = "red") +
      labs(x = "Oil Price", y = "SPX_log", title = "Oil Price vs SPX_log") +
      theme_minimal() +
      theme(text = element_text(size = 14))
    ggplotly(p)
  })
  output$comparisonPlot <- renderPlotly({
    # Extract month from the 'Date' column and convert to month abbreviations
    oil$Month <- format(oil$Date, "%b")
    
    # Convert Month to a factor with levels in the correct order
    oil$Month <- factor(oil$Month, levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
    
    # Filter data based on selected year
    if (input$year != "All") {
      oil_filtered <- subset(oil, format(Date, "%Y") == input$year)
    } else {
      oil_filtered <- oil
    }
    
    # Group by month and calculate the average oil price for each month
    monthly_avg_oilprice <- aggregate(OILPRICE ~ Month, oil_filtered, mean)
    
    # Plotting a bar plot for average oil price over different months
    p <- ggplot(monthly_avg_oilprice, aes(x = Month, y = OILPRICE)) +
      geom_bar(stat = "identity", fill = "blue") +
      labs(title = "Average Oil Price Over Different Months", x = "Month", y = "Average Oil Price") +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
    ggplotly(p)
  })
  
  # Correlation Matrix Heatmap
  output$heatmapPlot <- renderPlotly({
    oil_numeric <- oil %>% select(-c(Date, Month))
    corr_matrix <- cor(oil_numeric, use = "complete.obs")
    fig <- plot_ly(
      x = colnames(corr_matrix), 
      y = colnames(corr_matrix), 
      z = corr_matrix, 
      type = "heatmap", 
      colorscale = "RdBu", 
      zmin = -1, 
      zmax = 1
    ) %>%
      layout(
        title = "Correlation Matrix Heatmap", 
        xaxis = list(title = "", tickangle = 45, tickfont = list(size = 12)), 
        yaxis = list(title = "", tickfont = list(size = 12))
      )
    fig
  })
  observeEvent(input$apply_transformation, {
    driver <- oil[[input$driver]]
    new_name <- input$new_name
    if (input$transformation == "Rolling Standard Deviation") {
      oil[[new_name]] <- rolling_sd(driver, input$window)
      transformation_desc <- paste("Rolling Standard Deviation (window =", input$window, ")")
    } else if (input$transformation == "Rolling Mean") {
      oil[[new_name]] <- rolling_mean(driver, input$window)
      transformation_desc <- paste("Rolling Mean (window =", input$window, ")")
    } else if (input$transformation == "Lagging") {
      oil[[new_name]] <- lag_series(driver, input$lag_order)
      transformation_desc <- paste("Lagging (order =", input$lag_order, ")")
    } else if (input$transformation == "Difference") {
      oil[[new_name]] <- calculate_difference(oil$OILPRICE, oil$respLAG)
      transformation_desc <- "Difference (OILPRICE - respLAG)"
    }
    # Update metadata
    if (is.null(metadata[[new_name]])) {
      metadata[[new_name]] <- list()
    }
    metadata[[new_name]] <- c(metadata[[new_name]], transformation_desc)
    # Perform statistical tests
    norm_test <- normality_test(oil[[new_name]])
    stat_test <- stationarity_test(oil[[new_name]])
    corr_coeff <- correlation_coefficient(oil[[new_name]], oil$OILPRICE)
    stats_output <- paste(
      "Normality Test (Shapiro-Wilk): p-value =", norm_test$p.value, "\n",
      "Stationarity Test (ADF): p-value =", stat_test$p.value, "\n",
      "Correlation with OILPRICE: ", corr_coeff
    )
    output$transformationPlot <- renderPlotly({
      p <- ggplot(oil, aes_string(x = "Date", y = new_name)) +
        geom_line(color = "blue") +
        labs(x = "Date", y = new_name, title = paste("Transformation:", new_name)) +
        theme_minimal() +
        theme(text = element_text(size = 14))
      ggplotly(p)
    })
    output$statsOutput <- renderText({
      stats_output
    })
    # Update metadata table
    metadata_df <- data.frame(
      Driver = names(metadata),
      Transformations = sapply(metadata, function(x) paste(x, collapse = " -> ")),
      Normality_p_value = sapply(names(metadata), function(name) normality_test(oil[[name]])$p.value),
      Stationarity_p_value = sapply(names(metadata), function(name) stationarity_test(oil[[name]])$p.value)
    )
    output$metadataTable <- renderDataTable({
      metadata_df
    })
  })
  # Reactive expression to store metadata_df
  metadata_df_reactive <- reactive({
    df <- data.frame(
      Driver = names(metadata),
      Transformations = sapply(metadata, function(x) paste(x, collapse = " -> ")),
      Normality_p_value = sapply(names(metadata), function(name) normality_test(oil[[name]])$p.value),
      Stationarity_p_value = sapply(names(metadata), function(name) stationarity_test(oil[[name]])$p.value)
    )
  })
  
  # Download handler for dataset
  output$downloadData <- downloadHandler(
    filename = function() {
      paste("transformed_data-", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(oil, file)
    }
  )
  # Download handler for statistics
  output$downloadStats <- downloadHandler(
    filename = function() {
      paste("transformation_statistics-", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(metadata_df_reactive(), file)
    }
  )
}

# Run the Shiny app
shinyApp(ui = ui, server = server)

