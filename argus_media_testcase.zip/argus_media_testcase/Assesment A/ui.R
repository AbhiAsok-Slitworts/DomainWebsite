library(shiny)
library(shinydashboard)
library(plotly)

# Define UI for the Shiny dashboard
ui <- dashboardPage(
  dashboardHeader(title = "Oil Price Dashboard"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Transformations", tabName = "transformations", icon = icon("sliders-h")),
      menuItem("Metadata", tabName = "metadata", icon = icon("table"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "dashboard",
              fluidRow(
                box(title = "Oil Price vs SPX_log", status = "primary", solidHeader = TRUE, 
                    plotlyOutput("scatterPlot", height = "500px"), width = 6,
                    p(em("This scatter plot shows the relationship between the oil price (OILPRICE) and the S&P 500 index (SPX_log). It helps to visualize how changes in oil prices correlate with the stock market."))),
                box(title = "Average Oil Price Over Months Across Years", status = "primary", solidHeader = TRUE, 
                    plotlyOutput("comparisonPlot", height = "500px"), width = 6,
                    p(em("This bar plot shows the average oil price over different months. You can filter the data by selecting a specific year from the dropdown menu.")),
                    selectInput("year", "Select Year:", choices = c("All", unique(format(oil$Date, "%Y"))), selected = "All")
                )
              ),
              fluidRow(
                box(title = "Correlation Matrix Heatmap", status = "primary", solidHeader = TRUE, collapsible = TRUE,
                    width = 12,
                    plotlyOutput("heatmapPlot", height = "80vh"),
                    p(em("This heatmap visualizes the correlations between all variables in the dataset. The color scale indicates the strength and direction of the correlations, with blue representing negative correlations and red representing positive correlations.")))
              )
      ),
      tabItem(tabName = "transformations",
              fluidRow(
                box(title = "Transformation Settings", status = "primary", solidHeader = TRUE, width = 12,
                    selectInput("driver", "Select Driver:", choices = colnames(oil)),
                    selectInput("transformation", "Select Transformation:", choices = c("Rolling Standard Deviation", "Rolling Mean", "Lagging", "Difference")),
                    numericInput("window", "Window Size (for Rolling SD/Mean):", value = 5, min = 1),
                    numericInput("lag_order", "Lag Order (for Lagging):", value = 1, min = 1),
                    textInput("new_name", "Name for Transformed Driver:", value = "transformed_driver"),
                    actionButton("apply_transformation", "Apply Transformation"),
                    plotlyOutput("transformationPlot", height = "500px"),
                    verbatimTextOutput("statsOutput")
                )
              )
      ),
      tabItem(tabName = "metadata",
              fluidRow(
                box(title = "Metadata", status = "primary", solidHeader = TRUE, width = 12,
                    DT::dataTableOutput("metadataTable"),
                    downloadButton("downloadData", "Download Dataset"),
                    downloadButton("downloadStats", "Download Statistics")
                )
              )
      )
    )
  )
)

